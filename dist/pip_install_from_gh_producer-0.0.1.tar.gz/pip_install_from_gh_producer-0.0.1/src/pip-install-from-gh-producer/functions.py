def test_function():
    print(f"I am the test function")
