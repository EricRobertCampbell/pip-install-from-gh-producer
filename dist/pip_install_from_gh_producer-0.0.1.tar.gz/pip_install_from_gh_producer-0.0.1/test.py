#!/usr/bin/env python3

from pip_install_from_gh_producer import test_function

def main():
    test_function()

if __name__ == '__main__':
    main()
